import React from 'react';
import './HolaMundo.css'; 

const HolaMundo = () => {
    return (
        <div className="hola-mundo">
            <p>Hola, mundo!</p>
        </div>
    );
}

export default HolaMundo;
