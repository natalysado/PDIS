const tasks = [
    { id: 1, title: "Tarea 1", description: "Descripción de tarea 1", completed: false, createdAt: new Date() },
    { id: 2, title: "Tarea 2", description: "Descripción de tarea 2", completed: true, createdAt: new Date() },
  ];
  
  export default tasks;