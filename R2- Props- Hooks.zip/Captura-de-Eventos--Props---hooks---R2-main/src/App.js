import React from "react";
import "./App.css";
import Notas from "./Notas";

function App() {
    return (
        <div className="App">
            <Notas />
        </div>
    );
}

export default App;
