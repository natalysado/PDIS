import React from 'react';
import Formulario from './Formulario';

const App = () => {
  return (
    <div className="App">
      <Formulario />
    </div>
  );
};

export default App;
